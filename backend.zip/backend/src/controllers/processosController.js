const firebird = require('node-firebird');
const dbConfig = require('../config/db');

exports.getProcessos = (req, res) => {
  // (Opcional) filtro por cliente: /processos?cd_cliente=123
  const { cd_cliente } = req.query;
  let query = `SELECT CD_PROCESSO, TP_DECLARACAO, TPO_PROCESSO, CD_CLIENTE, NR_DI_DUIMP, DT_REGISTRO, IDT_EMBARQUE, INSCRICAO_SEFAZ, QTD_CONTAINER, VL_FOB_LOCAL_EMBARQUE, CD_MOEDA_FOB, VL_FOB_MOEDA_NACIONAL, VL_FRETE_MOEDA, CD_MOEDA_FRETE, VL_FRETE_MOEDA_NACIONAL, VL_FRETE_PRAPAID_MOEDA, VL_FRETE_COLECT_MOEDA, VL_SEGURO_MOEDA, CD_MOEDA_SEGURO, VL_SEGURO_MOEDA_NACACIONAL, QTD_ADICOES, PESO_LIQUIDO, PESO_BRUTO, HAWB_BL, NM_CANAL, NM_ARMAZEM, NM_VIA_TRANSPORTE, NR_DOC_CHEGADA, NM_DOC_CHEGADA, CD_RECINTO_ALFADEGADO, DT_EMBARQUE, DT_CHEGADA, DT_LIBERACAO, NM_LOCAL_EMBARQUE, DT_ENTREGA, NM_EXPORTADOR, VL_TX_DOLAR_DI, NM_AGENTE_CARGA, VL_CIF_DOLAR, VL_TX_SISCOMEX, VL_TCIF, VL_TX_MOEDA_FOB, VL_TX_MOEDA_FRETE, VL_TX_MOE_SEGURO, VL_FOB_REAL, VL_FRETE_REAL, VL_SEGURO_REAL, VL_II_RECOLHER, VL_IPI_RECOLHER, VL_PIS_RECOLHER, VL_COFINS_RECOLHER, VL_TAXAS_RECOLHER, VL_II_DEVIDO, VL_IPI_DEVIDO, VL_PIS_DEVIDO, VL_COFINS_DEVIDO, VL_II_PAGO, VL_IPI_PAGO, VL_PIS_PAGO, VL_COFINS_PAGO, VL_ANTIDUMPIG_PAGO, VL_LI_POSTERIOR_PAGO, VL_CIDE, BANCO_AGENCIA_CONTA, USADO_INDUSTRIA, USADO_ATIVO_PPB, USADO_ATIVO_NAO_PPB, USADO_USO_CONSUMO, USADO_COMERCIALIZACAO, USADO_PEXPAM, CD_INCOTERM, QTD_VOLUMES, NM_VEICULO_TRANSPORTE, NM_AGENTE_TRANSPORTADOR, NR_CE_MERCANTE, NR_PROTOCOLO FROM PROCESSOS_REGISTRADOS`;
  let params = [];
  if (cd_cliente) {
    query += ' WHERE CD_CLIENTE = ?';
    params.push(cd_cliente);
  }
  firebird.attach(dbConfig, (err, db) => {
    if (err) {
      return res.status(500).json({ error: 'Erro ao conectar ao banco.', details: err.message });
    }
    db.query(query, params, (err, result) => {
      db.detach();
      if (err) {
        return res.status(500).json({ error: 'Erro na consulta.', details: err.message });
      }
      res.json({ processos: result });
    });
  });
};
