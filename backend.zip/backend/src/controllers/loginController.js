const firebird = require('node-firebird');
const dbConfig = require('../config/db');

exports.login = (req, res) => {
  const { cnpj, senha } = req.body;
  if (!cnpj || !senha) {
    return res.status(400).json({ error: 'CNPJ e senha são obrigatórios.' });
  }
  firebird.attach(dbConfig, (err, db) => {
    if (err) {
      return res.status(500).json({ error: 'Erro ao conectar ao banco.', details: err.message });
    }
    db.query(
      'SELECT * FROM CLIENTE WHERE INSC_CGC_CLIENTE = ? AND SENHA = ?',
      [cnpj, senha],
      (err, result) => {
        db.detach();
        if (err) {
          return res.status(500).json({ error: 'Erro na consulta.', details: err.message });
        }
        if (!result.length) {
          return res.status(401).json({ error: 'CNPJ ou senha inválidos.' });
        }
        res.json({ success: true, cliente: result[0] });
      }
    );
  });
};
