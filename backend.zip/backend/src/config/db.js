module.exports = {
  host: process.env.DB_HOST,
  port: parseInt(process.env.DB_PORT, 10),
  database: process.env.DB_PATH,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  role: undefined,
  pageSize: 16384,
};
