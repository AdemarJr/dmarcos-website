require('dotenv').config({ path: __dirname + '/../../.env' });
const express = require('express');

const loginRouter = require('./routes/login');
const processosRouter = require('./routes/processos');

const app = express();
app.use(express.json());


app.use('/login', loginRouter);
app.use('/processos', processosRouter);

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Backend API rodando na porta ${PORT}`);
});
