const express = require('express');
const processosController = require('../controllers/processosController');

const router = express.Router();

router.get('/', processosController.getProcessos);

module.exports = router;
