# Backend - Guia de Instalação e Uso Remoto

## 1. Pré-requisitos

- Node.js 18+ instalado (recomendado)
- Firebird Server acessível remotamente
- Acesso SSH ao servidor remoto
- Git instalado
- (Opcional) Docker instalado
- (Opcional) PM2 instalado globalmente (`npm install -g pm2`)

## 2. Clonando o projeto

No servidor remoto:

```bash
git clone <URL_DO_REPOSITORIO>
cd backend
```

## 3. Instalando dependências

```bash
pnpm install # ou npm install
```

## 4. Configurando variáveis de ambiente

Crie um arquivo `.env` na raiz do backend com o seguinte formato:

```
PORT=3001
DB_HOST=<IP ou hostname do Firebird>
DB_PORT=3050
DB_PATH=<caminho do banco .fdb>
DB_USER=<usuario>
DB_PASSWORD=<senha>
```

## 5. Rodando o backend

### Local

```bash
pnpm start # ou npm start
```

### Com PM2 (produção)

```bash
pm2 start src/index.js --name firebird-backend
pm2 logs firebird-backend # para ver logs
```

### Com Docker (opcional)

Crie um `Dockerfile` (exemplo):

```
FROM node:18
WORKDIR /app
COPY . .
RUN pnpm install --prod
CMD ["node", "src/index.js"]
```

Build e run:

```bash
docker build -t firebird-backend .
docker run -d --name firebird-backend -p 3001:3001 --env-file .env firebird-backend
```

## 6. Endpoints disponíveis

- `POST /login` - Autenticação de cliente
  - Body: `{ cnpj, senha }`
- `GET /processos` - Lista de processos
  - Query opcional: `cd_cliente`

## 7. Segurança e Deploy

- Use firewall (ex: UFW) para liberar apenas a porta do backend (`ufw allow 3001`)
- Nunca exponha o Firebird diretamente
- Use HTTPS (proxy reverso: Nginx, Caddy, etc.)
- Atualize dependências regularmente
- Monitore logs com PM2 ou Docker

## 8. Testando

- Use ferramentas como Postman ou cURL para testar endpoints
- Exemplo:

```bash
curl -X POST http://<IP>:3001/login -H "Content-Type: application/json" -d '{"cnpj":"12345678901234","senha":"minhasenha"}'
```

## 9. Troubleshooting

- Verifique logs (`pm2 logs` ou `docker logs`)
- Confirme variáveis .env
- Teste conexão Firebird local
- Consulte documentação oficial [node-firebird](https://github.com/hgourvest/node-firebird)

---

Qualquer dúvida, consulte o responsável técnico ou abra um issue no repositório.
